import java.time.LocalTime;
import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.scene.text.Text;

public class DisplayClock extends Application {
    
    private static int hour;
    private static int minute;
    private static int second;
    @Override // Override the start method in the Application class
    public void start(Stage primaryStage) {
        BorderPane bp = new BorderPane();
        Pane pane = new Pane();
                        double clockRadius = Math.min(250, 250) * 0.8 * 0.5;
                           double centerX = 250 /2;
                         double centerY = 250 /2;
                   
                         // Draw circle
                          Circle circle = new Circle(centerX, centerY, clockRadius);
                         circle.setFill(Color.WHITE);
                         circle.setStroke(Color.BLACK);
                         Text t1 = new Text(centerX - 5, centerY - clockRadius + 12, "12");
                         Text t2 = new Text(centerX - clockRadius + 3, centerY + -2, "9");
                         Text t3 = new Text(centerX + clockRadius - 10, centerY + 3, "3");
                         Text t4 = new Text(centerX - 3, centerY + clockRadius - 3, "6");
                         Text t5 = new Text(centerX - 61, centerY - clockRadius + 32, "11");
                         Text t6 = new Text(centerX - clockRadius + 12, centerY + -35, "10");
                         Text t7 = new Text(centerX + clockRadius - 25, centerY + 52, "4");
                         Text t8 = new Text(centerX + 33, centerY + clockRadius - 10, "5");
                         Text t9 = new Text(centerX + 55, centerY - clockRadius + 32, "1");
                         Text t10 = new Text(centerX + clockRadius - 15, centerY - 31, "2");
                         Text t11 = new Text(centerX - 63, centerY + clockRadius - 25, "7");
                         Text t12 = new Text(centerX - (Math.sqrt(3)/2)* (clockRadius - 5), centerY -  (clockRadius - 5) *-1/2 , "8");
                   
                         // Draw second hand
                         double sLength = clockRadius * 0.8;
                         double secondX = centerX + sLength *
                           Math.sin(second * (2 * Math.PI / 60));
                         double secondY = centerY - sLength *
                           Math.cos(second * (2 * Math.PI / 60));
                         Line sLine = new Line(centerX, centerY, secondX, secondY);
                         sLine.setStroke(Color.RED);
                   
                         // Draw minute hand
                         double mLength = clockRadius * 0.65;
                         double xMinute = centerX + mLength *
                           Math.sin(minute * (2 * Math.PI / 60));
                         double minuteY = centerY - mLength * Math.cos(minute * (2 * Math.PI / 60));
                         Line mLine = new Line(centerX, centerY, xMinute, minuteY);
                         mLine.setStroke(Color.GREEN);
                   
                         // Draw hour hand
                         double hLength = clockRadius *  0.5;
                         double hourX = centerX + hLength *
                           Math.sin((hour % 12 + minute / 60.0) * (2 * Math.PI / 12));
                         double hourY = centerY - hLength * Math.cos((hour % 12 + minute / 60.0) * (2 * Math.PI / 12));
                         Line hLine = new Line(centerX, centerY, hourX, hourY);
                         hLine.setStroke(Color.GREEN);
                   
                       pane.getChildren().clear();
                        pane.getChildren().addAll(circle, t1, t2, t3, t4, t5, t6, t7, t8, t9, t10, t11, t12, sLine, mLine, hLine);
        // Create a clock and a label
        String timeString = getHour() + ":" + getMinute() + ":" + getSecond();
        Label lblCurrentTime = new Label(timeString);

        // Place clock and label in border pane
        bp.setCenter(pane);
        bp.setBottom(lblCurrentTime);
        BorderPane.setAlignment(lblCurrentTime, Pos.TOP_CENTER);

        // Create a scene and place it in the stage
        Scene scene = new Scene(bp, 250, 250);
        primaryStage.setTitle("DisplayClock"); // Set the stage title
        primaryStage.setScene(scene); // Place the scene in the stage
        primaryStage.show(); // Display the stage
    }
    public static void main(String[] args) {
        launch(args);
    }
    public static int getHour() {
        return LocalTime.now().getHour();
        
      }
      public static int getMinute() {
          return LocalTime.now().getMinute();
        }
        public static int getSecond() {
            return LocalTime.now().getSecond();
          }
}